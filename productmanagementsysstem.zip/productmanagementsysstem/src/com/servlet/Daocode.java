package com.servlet;

public class Daocode {
	
	
	public boolean addProduct(Product product) {
		int count1 = 0;
		int count2 = 0;
		ResultSet rs = null;
		String sql="delete from productdiscounttable where productId=?";
		String sql1 = "update  product productName=?,description=?,manufacturing_date=?,expiry_date=?,max_retail_price=?,"
				+ "category_Id=?,sub_category_Id=?,supplierId=?,quantity=?,rating? where productId=?";
		try {
			PreparedStatement stmt = getMySqlConnection().prepareStatement(sql1);
			stmt.setString(1, product.getProduct_Name());
			stmt.setString(2, product.getDescription());
			stmt.setDate(3, new java.sql.Date(product.getManufacturing_Date().getTime()));
			stmt.setDate(4, new java.sql.Date(product.getExpiry_Date().getTime()));
			stmt.setDouble(5, product.getMaximum_Retail_Price());
			stmt.setInt(6, product.getCategory().getCategory_Id());
			stmt.setInt(7, product.getSubCategory().getSubCategory_Id());
			stmt.setInt(8, product.getSupplier().getSupplier_Id());
			stmt.setInt(9, product.getQuantity());
			stmt.setDouble(10, product.getRating());
			stmt.setInt(11, product.getproduct_Id());
			count1 = stmt.executeUpdate();
			String sql2 = "select * from product";
			
			String sql3 = "insert into productdiscounttable value(?,?)";
			PreparedStatement stmt2 = getMySqlConnection().prepareStatement(sql3);
			List<Discount> discounts = product.getDiscounts();
			for (Discount d : discounts) {
				stmt2.setInt(1, id);
				stmt2.setInt(2, d.getDiscount_Id());
				count2 = stmt2.executeUpdate();
			}
			// System.out.println(count1);
			// System.out.println(count2);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;


}
